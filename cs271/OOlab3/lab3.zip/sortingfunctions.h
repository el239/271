#ifndef SORTINGFUNCTIONS
#define SORTINGFUNCTIONS

int selectionSort ( int * const data, int size );
int insertionSort ( int * const data, int size );

#endif 
