#ifndef FUNCTIONS4
#define FUNCTIONS4

#include <stdio.h>

void splitAlpha(const char * original, char * lower, char * upper);
void printSequences(const char * text);

#endif 
